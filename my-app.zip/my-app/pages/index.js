function HomePage() {
  return <h1>Hello, cPanel!</h1>;
}

export default HomePage;